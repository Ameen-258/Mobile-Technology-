package com.example.u3284065mtassignment;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.u3284065mtassignment.AnalysisItem;
import com.example.u3284065mtassignment.R;

import java.io.File;
import java.util.ArrayList;

public class AnalysisAdapter extends ArrayAdapter<AnalysisItem> {

    Context context;
    ArrayList<AnalysisItem> items;

    public AnalysisAdapter(Context context, ArrayList<AnalysisItem> items) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        ImageView imageView = view.findViewById(R.id.imageViewListItem);
        TextView textView = view.findViewById(R.id.textViewListItem);

        AnalysisItem item = items.get(position);

        textView.setText(item.reader + "\n" + item.result);

        File file = new File(context.getFilesDir(), item.filename);
        if (file.exists()) {
            imageView.setImageURI(Uri.fromFile(file));
        }

        if (position % 2 == 0) {
            view.setBackgroundColor(Color.WHITE);
        } else {
            view.setBackgroundColor(Color.LTGRAY);
        }

        return view;
    }
}