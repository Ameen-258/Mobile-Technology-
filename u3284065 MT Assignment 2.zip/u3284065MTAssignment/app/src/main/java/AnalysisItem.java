package com.example.u3284065mtassignment;
public class AnalysisItem {
    public String id;
    public String reader;
    public String result;
    public String filename;

    public AnalysisItem() {
    }

    public AnalysisItem(String id, String reader, String result, String filename) {
        this.id = id;
        this.reader = reader;
        this.result = result;
        this.filename = filename;
    }
}