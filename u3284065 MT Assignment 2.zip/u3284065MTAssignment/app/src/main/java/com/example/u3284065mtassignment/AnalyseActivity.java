package com.example.u3284065mtassignment;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.List;
import java.util.Locale;

public class AnalyseActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;

    private String reader;
    private String imageName;
    private Uri imageFileUri;

    private TextView textViewTitle;
    private TextView textViewResult;
    private ImageView imageView;
    private Button buttonEdit;

    private String finalResult = "";

    private final ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {

                    if (result.getData() != null && result.getData().getData() != null) {
                        imageFileUri = result.getData().getData();
                    }

                    imageView.setImageURI(imageFileUri);
                    processImage();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyse);

        textViewTitle = findViewById(R.id.textViewAnalyseTitle);
        textViewResult = findViewById(R.id.textViewResult);
        imageView = findViewById(R.id.imageViewAnalyse);
        buttonEdit = findViewById(R.id.buttonEditResult);

        Button buttonCamera = findViewById(R.id.buttonCamera);
        Button buttonGallery = findViewById(R.id.buttonGallery);

        reader = getIntent().getStringExtra(MainActivity.EXTRA_READER);
        imageName = getIntent().getStringExtra(MainActivity.EXTRA_IMAGE);

        int imageId = getResources().getIdentifier(imageName, "drawable", getPackageName());
        imageView.setImageResource(imageId);

        buttonCamera.setOnClickListener(v -> openCamera());
        buttonGallery.setOnClickListener(v -> loadImage());

        buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(AnalyseActivity.this, EditActivity.class);
            intent.putExtra(MainActivity.EXTRA_READER, reader);
            intent.putExtra(MainActivity.EXTRA_RESULT, finalResult);
            intent.putExtra(MainActivity.EXTRA_IMAGE_URI, imageFileUri.toString());
            startActivity(intent);
        });
    }

    private boolean checkPermission() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;

        if (!granted) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_PERMISSION);
        }

        return granted;
    }

    private void openCamera() {
        if (!checkPermission()) {
            return;
        }

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues()
        );

        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    private void loadImage() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    private void processImage() {
        try {
            InputImage image = InputImage.fromFilePath(this, imageFileUri);

            if (reader.equals("Barcode Reader")) {
                processBarcode(image);
            } else if (reader.equals("Content Reader")) {
                processContent(image);
            } else {
                processText(image);
            }

        } catch (Exception e) {
            textViewResult.setText("Error processing image: " + e.getMessage());
        }
    }

    private void processBarcode(InputImage image) {
        BarcodeScanner scanner = BarcodeScanning.getClient();

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    StringBuilder output = new StringBuilder();
                    output.append("Detected barcode:\n");

                    if (barcodes.size() == 0) {
                        output.append("No barcode detected");
                    } else {
                        int count = 1;
                        for (Barcode barcode : barcodes) {
                            output.append(count).append(". ").append(barcode.getRawValue()).append("\n");
                            count++;
                        }
                    }

                    showResult(output.toString());
                })
                .addOnFailureListener(e -> showResult("Detected barcode:\nError: " + e.getMessage()));
    }

    private void processContent(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);

        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    StringBuilder output = new StringBuilder();
                    output.append("Recognised image content:\n");

                    if (labels.size() == 0) {
                        output.append("No content recognised");
                    } else {
                        for (int i = 0; i < labels.size(); i++) {
                            output.append(i + 1)
                                    .append(". ")
                                    .append(labels.get(i).getText())
                                    .append(" (")
                                    .append(String.format(Locale.getDefault(), "%.2f", labels.get(i).getConfidence()))
                                    .append(")\n");
                        }
                    }

                    showResult(output.toString());
                })
                .addOnFailureListener(e -> showResult("Recognised image content:\nError: " + e.getMessage()));
    }

    private void processText(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(text -> showResult("Extracted text:\n" + text.getText()))
                .addOnFailureListener(e -> showResult("Extracted text:\nError: " + e.getMessage()));
    }

    private void showResult(String result) {
        finalResult = result;
        textViewTitle.setText(reader);
        textViewResult.setText(result);
        buttonEdit.setVisibility(View.VISIBLE);
    }
}