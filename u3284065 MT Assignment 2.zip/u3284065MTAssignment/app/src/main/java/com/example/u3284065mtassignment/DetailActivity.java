package com.example.u3284065mtassignment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class DetailActivity extends AppCompatActivity {

    private String id;
    private String reader;
    private String result;
    private String filename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView textViewReader = findViewById(R.id.textViewDetailReader);
        TextView textViewResult = findViewById(R.id.textViewDetailResult);
        ImageView imageView = findViewById(R.id.imageViewDetail);

        Button buttonEdit = findViewById(R.id.buttonEdit);
        Button buttonDelete = findViewById(R.id.buttonDelete);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        id = getIntent().getStringExtra(MainActivity.EXTRA_ID);
        reader = getIntent().getStringExtra(MainActivity.EXTRA_READER);
        result = getIntent().getStringExtra(MainActivity.EXTRA_RESULT);
        filename = getIntent().getStringExtra(MainActivity.EXTRA_FILENAME);

        textViewReader.setText(reader);
        textViewResult.setText(result);

        File file = new File(getFilesDir(), filename);
        if (file.exists()) {
            imageView.setImageURI(Uri.fromFile(file));
        }

        buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, EditActivity.class);
            intent.putExtra(MainActivity.EXTRA_ID, id);
            intent.putExtra(MainActivity.EXTRA_READER, reader);
            intent.putExtra(MainActivity.EXTRA_RESULT, result);
            intent.putExtra(MainActivity.EXTRA_FILENAME, filename);
            startActivity(intent);
        });

        buttonDelete.setOnClickListener(v -> {
            FirebaseDatabase.getInstance()
                    .getReference("analysedImages")
                    .child(id)
                    .removeValue()
                    .addOnSuccessListener(unused -> {
                        Intent intent = new Intent(DetailActivity.this, ListActivity.class);
                        startActivity(intent);
                        finish();
                    });
        });

        buttonCancel.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, ListActivity.class);
            startActivity(intent);
            finish();
        });
    }
}