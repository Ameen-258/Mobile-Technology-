package com.example.u3284065mtassignment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class EditActivity extends AppCompatActivity {

    private EditText editTextReader;
    private EditText editTextResult;
    private ImageView imageView;

    private String id;
    private String imageUriString;
    private String filename;

    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editTextReader = findViewById(R.id.editTextReader);
        editTextResult = findViewById(R.id.editTextResult);
        imageView = findViewById(R.id.imageViewEdit);
        Button buttonSave = findViewById(R.id.buttonSave);

        dbRef = FirebaseDatabase.getInstance().getReference("analysedImages");

        id = getIntent().getStringExtra(MainActivity.EXTRA_ID);
        filename = getIntent().getStringExtra(MainActivity.EXTRA_FILENAME);
        imageUriString = getIntent().getStringExtra(MainActivity.EXTRA_IMAGE_URI);

        String reader = getIntent().getStringExtra(MainActivity.EXTRA_READER);
        String result = getIntent().getStringExtra(MainActivity.EXTRA_RESULT);

        editTextReader.setText(reader);
        editTextResult.setText(result);

        if (filename != null) {
            File file = new File(getFilesDir(), filename);
            imageView.setImageURI(Uri.fromFile(file));
        } else if (imageUriString != null) {
            imageView.setImageURI(Uri.parse(imageUriString));
        }

        buttonSave.setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String reader = editTextReader.getText().toString();
        String result = editTextResult.getText().toString();

        if (id == null) {
            id = dbRef.push().getKey();
            filename = "image_" + System.currentTimeMillis() + ".jpg";
            saveImageToInternalStorage(Uri.parse(imageUriString), filename);
        }

        com.example.u3284065mtassignment.AnalysisItem item = new com.example.u3284065mtassignment.AnalysisItem(id, reader, result, filename);

        dbRef.child(id).setValue(item)
                .addOnSuccessListener(unused -> {
                    Intent intent = new Intent(EditActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void saveImageToInternalStorage(Uri uri, String filename) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), filename);
            FileOutputStream outputStream = new FileOutputStream(file);

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            inputStream.close();
            outputStream.close();

        } catch (Exception e) {
            Toast.makeText(this, "Image save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
