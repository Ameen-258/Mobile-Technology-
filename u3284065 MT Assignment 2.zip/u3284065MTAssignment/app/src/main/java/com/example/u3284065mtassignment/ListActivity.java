package com.example.u3284065mtassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    private ArrayList<com.example.u3284065mtassignment.AnalysisItem> items;
    private com.example.u3284065mtassignment.AnalysisAdapter adapter;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ListView listView = findViewById(R.id.listViewAnalysed);
        Button buttonAdd = findViewById(R.id.buttonAdd);

        items = new ArrayList<>();
        adapter = new com.example.u3284065mtassignment.AnalysisAdapter(this, items);
        listView.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("analysedImages");

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                items.clear();

                for (DataSnapshot child : snapshot.getChildren()) {
                    com.example.u3284065mtassignment.AnalysisItem item = child.getValue(com.example.u3284065mtassignment.AnalysisItem.class);
                    if (item != null) {
                        item.id = child.getKey();
                        items.add(item);
                    }
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ListActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            com.example.u3284065mtassignment.AnalysisItem item = items.get(position);

            Intent intent = new Intent(ListActivity.this, DetailActivity.class);
            intent.putExtra(MainActivity.EXTRA_ID, item.id);
            intent.putExtra(MainActivity.EXTRA_READER, item.reader);
            intent.putExtra(MainActivity.EXTRA_RESULT, item.result);
            intent.putExtra(MainActivity.EXTRA_FILENAME, item.filename);
            startActivity(intent);
        });

        buttonAdd.setOnClickListener(v -> {
            Intent intent = new Intent(ListActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}