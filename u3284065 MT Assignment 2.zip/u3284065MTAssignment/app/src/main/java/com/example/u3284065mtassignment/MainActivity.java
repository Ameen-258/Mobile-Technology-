package com.example.u3284065mtassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_READER = "reader";
    public static final String EXTRA_IMAGE = "image";
    public static final String EXTRA_RESULT = "result";
    public static final String EXTRA_IMAGE_URI = "imageUri";
    public static final String EXTRA_ID = "id";
    public static final String EXTRA_FILENAME = "filename";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageViewBarcode = findViewById(R.id.imageViewBarcode);
        ImageView imageViewContent = findViewById(R.id.imageViewContent);
        ImageView imageViewText = findViewById(R.id.imageViewText);
        Button buttonList = findViewById(R.id.buttonList);

        imageViewBarcode.setOnClickListener(v -> openAnalyseActivity("Barcode Reader", "barcode"));
        imageViewContent.setOnClickListener(v -> openAnalyseActivity("Content Reader", "content"));
        imageViewText.setOnClickListener(v -> openAnalyseActivity("Text Reader", "text_reader"));

        buttonList.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            startActivity(intent);
        });
    }

    private void openAnalyseActivity(String reader, String imageName) {
        Intent intent = new Intent(MainActivity.this, AnalyseActivity.class);
        intent.putExtra(EXTRA_READER, reader);
        intent.putExtra(EXTRA_IMAGE, imageName);
        startActivity(intent);
    }
}