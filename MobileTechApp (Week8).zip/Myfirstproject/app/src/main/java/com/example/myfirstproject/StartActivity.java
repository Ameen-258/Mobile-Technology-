package com.example.myfirstproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button = findViewById(R.id.buttonUIEvent);
        button.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MainActivity.class);
            intent.putExtra("message", "Hello World!");
            startActivity(intent);
        });

        Button buttonL = findViewById(R.id.LocationServices);
        buttonL.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, LocationServicesActivity.class);
            startActivity(intent);
        });

        Button buttonF = findViewById(R.id.Firebase);
        buttonF.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
            startActivity(intent);
        });
    }

    public void openSQLite(View view) {
        startActivity(new Intent(this, SQLiteActivity.class));
    }

    public void openAnimation(View view) {
        startActivity(new Intent(this, AnimationActivity.class));
    }

    public void openMultimedia(View view) {
        startActivity(new Intent(this, MultimediaActivity.class));
    }
}
